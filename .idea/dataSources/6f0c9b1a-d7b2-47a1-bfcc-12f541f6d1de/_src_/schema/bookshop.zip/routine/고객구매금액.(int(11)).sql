CREATE PROCEDURE 고객구매금액(IN 기준_금액 INT)
  BEGIN
  SELECT 고객.이름, sum(판매내역.수량* 판매내역.판매단가) AS 판매금액
    FROM 판매주문
    INNER JOIN 고객 ON 판매주문.고객아이디 = 고객.아이디
    INNER JOIN 판매내역 ON 판매주문.판매연번 = 판매내역.주문연번
    WHERE 주문일자 >= 2018-01-01
    GROUP BY 고객.이름
    HAVING sum(판매내역.수량* 판매내역.판매단가) < 기준_금액
  ORDER BY 판매금액 DESC;
END;
